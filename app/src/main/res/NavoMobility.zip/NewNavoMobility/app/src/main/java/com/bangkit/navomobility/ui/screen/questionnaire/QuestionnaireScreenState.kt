package com.bangkit.navomobility.ui.screen.questionnaire

data class QuestionnaireScreenState(
    var placeSelected: String = ""
)